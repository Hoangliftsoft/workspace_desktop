public class Run {
    public static void main(String[] args) throws Exception {
        InVoice c = new InVoice(1, "a Hoang h", 5000);
    }
}
